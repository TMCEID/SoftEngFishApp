package model;

public class Friend {
    private final int friendId;
    public Friend(int friendId) { this.friendId = friendId; }
    public int getFriendId()    { return friendId; }
}
