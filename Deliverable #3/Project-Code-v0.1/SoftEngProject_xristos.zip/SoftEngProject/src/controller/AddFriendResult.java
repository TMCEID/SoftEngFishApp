package controller;

//outcome when the user tries to add a friend
public enum AddFriendResult { ADDED, ALREADY, NOT_FOUND }
